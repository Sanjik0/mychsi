<?php require('components/header.php'); ?>

		<!-- Banner -->

		<section id="One" class="wrapper style2 app-wrapper">
			<div class="app-wrapper__inner">
				<div class="align-left">
					<h2 class="title">My application</h2>
					<div class="app-item">
						<label>Date</label>
						<label>Type</label>
						<label>Status</label>
					</div>
					<div class="app-item mb-30">
						<label>10.10.2021</label>
						<label>Bachelor degree</label>
						<label class="approved">Approved</label>
					</div>


					<div class="app-item">
						<label>Date</label>
						<label>Type</label>
						<label>Status</label>
					</div>
					<div class="app-item mb-30">
						<label>10.10.2021</label>
						<label>Bachelor degree</label>
						<label class="checking">Checking</label>
					</div>


					<div class="app-item">
						<label>Date</label>
						<label>Type</label>
						<label>Status</label>
					</div>
					<div class="app-item">
						<label>10.10.2021</label>
						<label>Bachelor degree</label>
						<label class="failed">Failed</label>
					</div>
				</div>
			</div>
		</section>


<?php require('components/footer.php'); ?>