		<!-- Footer -->
		<footer id="footer">
			<div class="copyright">
				Copyright &copy; 2020-2021 mychsi.org All Rights Reserved
			</div>
		</footer>

		<!-- Scripts -->
		<script src="assets/js/jquery.min.js"></script>
		<script src="assets/js/jquery.scrollex.min.js"></script>
		<script src="assets/js/skel.min.js"></script>
		<script src="assets/js/util.js"></script>
		<script src="assets/js/main.js"></script>
		<script src="https://code.jquery.com/jquery-2.1.0.js"></script>
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
		<script src="assets/js/script.js" type="text/javascript"></script>

	</body>
</html>