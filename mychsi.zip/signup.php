<?php require('components/header.php'); ?>

		<section id="two" class="wrapper style2 bg_waves signup_section">
			<div class="inner">
				<div class="box signup_content">
					<div class="content">
						<div class="align-center">
							<h2>Sign up</h2>
						</div>
						<form method="post" action="#">
							<div class="row uniform" style="text-align: center;">
								<div class="12u">
									<label class="label_input_sigin">Email</label>
									<input class="input_sigin" type="email" name="email">
								</div>
								<div class="12u">
									<label class="label_input_sigin">Name</label>
									<input class="input_sigin" type="text" name="name">
								</div>
								<div class="12u">
									<label class="label_input_sigin">Surname</label>
									<input class="input_sigin" type="text" name="surname">
								</div>
								<div class="12u">
									<label class="label_input_sigin">Password</label>
									<input class="input_sigin" type="password" name="password">
								</div>
								<div class="12u">
									<label class="label_input_sigin">Password</label>
									<input class="input_sigin" type="password" name="password">
								</div>
								<div class="12u$">
									<input class="input_sigin" type="submit" value="Sign up">
								</div>
							</div>
						</form>
					</div>
				</div>
			</div>
		</section>

<?php require('components/footer.php'); ?>